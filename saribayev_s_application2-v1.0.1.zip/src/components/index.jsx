import { Text } from "./Text";
import { Heading } from "./Heading";
import { Img } from "./Img";
import { Button } from "./Button";
import { RatingBar } from "./RatingBar";
export { Text, Heading, Img, Button, RatingBar };
